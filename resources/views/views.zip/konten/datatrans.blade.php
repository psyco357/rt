@extends('layouts.pages')
@section('title', 'Data Transaksi')
@section('content')


    <div class="card">
        <div class="card-body">
            <div class="card-body">
                <ul class="nav nav-tabs nav-primary" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" data-bs-toggle="tab" href="#proses" role="tab" aria-selected="true">
                            <div class="d-flex align-items-center">
                                <div class="tab-icon"><i class='bx bx-home font-18 me-1'></i>
                                </div>
                                <div class="tab-title">Data Masuk</div>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#setujui" role="tab" aria-selected="false">
                            <div class="d-flex align-items-center">
                                <div class="tab-icon"><i class='bx bx-user-pin font-18 me-1'></i>
                                </div>
                                <div class="tab-title">Setujui</div>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#tolak" role="tab" aria-selected="false">
                            <div class="d-flex align-items-center">
                                <div class="tab-icon"><i class='bx bx-user-pin font-18 me-1'></i>
                                </div>
                                <div class="tab-title">Di Tolak</div>
                            </div>
                        </a>
                    </li>

                </ul>
                <div class="tab-content py-3">
                    <div class="tab-pane fade show active" id="proses" role="tabpanel">
                        @include('molekul.tabletrans')
                    </div>
                    <div class="tab-pane fade" id="setujui" role="tabpanel">
                        @include('molekul.tabletrans')
                    </div>
                    <div class="tab-pane fade" id="tolak" role="tabpanel">
                        @include('molekul.tabletrans')
                    </div>
                </div>
            </div>

        </div>
    </div>


@endsection
